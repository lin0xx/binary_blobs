
from vix import Vix
import time,sys

vm = Vix()

print "Connecting"
vm.Connect()
print "Opening vm"
vm.Open("E:\\Old and backup VMs\\Windows XP\\Windows XP Professional.vmx")
#print "Powering On vm"
#vm.PowerOn()
#print "Waiting a bit..."
#time.sleep(10)
#print "Powering off vm"
#vm.PowerOff()
print "Reverting to snapshot 0"
vm.GetRootSnapshot()
vm.RevertToSnapshot()
"Sleeping"
time.sleep(10)
print "Disconnecting"
vm.Disconnect()
