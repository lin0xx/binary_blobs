A work in progress trying to get the proxy com object built as a 
native DLL or EXE.

 - Mike
 