"""
Architecture Support Modules

"""
# Copyright (C) 2007 Invisigoth - See LICENSE file for details
