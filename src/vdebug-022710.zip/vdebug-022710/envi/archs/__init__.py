"""
The new top level home for all the envi architecture modules.
"""
